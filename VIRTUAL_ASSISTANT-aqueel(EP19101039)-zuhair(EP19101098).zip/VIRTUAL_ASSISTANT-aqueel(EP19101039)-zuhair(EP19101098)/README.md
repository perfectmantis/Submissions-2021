# Karachi University MCS FYP
## Semester 4 Year 2020
Title: **_Virtual Assistant_**
Team Members:
- Muhammad Aqueel (EP-19101039)
- Zuhair Nasim (EP-19101098)

[**_Virtual Assistant_** 
Demo Youtube Video](https://www.youtube.com/watch?v=EQvJlTpctwg)
![](https://img.youtube.com/vi/EQvJlTpctwg/0.jpg)
