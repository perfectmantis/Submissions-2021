state = 1

# 0 = sleep
# 1 = awake