
export interface AppResponse {
    isSuccessful: Boolean;
    //objectId: number;
    data: any;
   errors: any;
  //  Data: any;
}