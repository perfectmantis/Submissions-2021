enum Status {
    Deleting =1,
    Editing,
    Existing,
    New
}