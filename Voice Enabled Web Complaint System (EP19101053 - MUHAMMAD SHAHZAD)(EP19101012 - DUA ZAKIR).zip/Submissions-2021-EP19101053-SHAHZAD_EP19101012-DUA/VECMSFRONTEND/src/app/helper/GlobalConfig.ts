import { Injector } from "@angular/core";

export const GlobalConfig = {
    url: { api: <string>{} },
    link: {exceptapi :<string>{}},
    injector: <Injector>{}
}